1A Motor – neue Suchseite

Diese drei Dateien zusammen in denselben Ordner hochladen:
- suche.html
- suche-live.js
- suche-hero-neu.png

Vorher am besten die vorhandenen Dateien sichern.
Die Seite unterstützt sowohl ?cat=Roller+Motor als auch den alten Parameter ?category=Roller+Motor.
Der bestehende Header und die Logo-Struktur wurden nicht neu aufgebaut.
