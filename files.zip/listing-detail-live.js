/**
 * 1A Motor — listing-detail-live.js (v2, Oktober 2026)
 * Lädt ein Inserat aus Supabase und füllt listing-detail.html.
 *
 * Neu gegenüber v1:
 *  - Hero mit Galerie (Pfeile, Tastatur, Swipe, Vollbild) + Kaufbox
 *  - Alle Verknüpfungen echt: Brotkrumen, Kategorie-/Hersteller-Suche, Standort/Route,
 *    Werkstätten, Melden, Teilen, Merken (gleicher Speicher wie suche.html)
 *  - Ähnliche Anzeigen funktionieren wieder (categories.id fehlte in der Abfrage)
 *  - Lieferadresse wird jetzt wirklich mitgesendet (vorher ging sie verloren)
 *  - Versandoptionen werden separat geladen (bricht die Seite nicht, falls die Spalte fehlt)
 *  - Werbeflächen: klar als "Anzeige" gekennzeichnet, Cookie-gated, mit Hausanzeige als Fallback
 */
(function () {
  "use strict";

  /* ═════════════════════════════════════════════════════════
     WERBE-KONFIGURATION
     ─────────────────────────────────────────────────────────
     slots: echte Anzeigenblock-IDs aus dem AdSense-Konto.
       Leerer Wert = es wird nur die Hausanzeige gezeigt (kein AdSense-Aufruf).
       sidebar   → bestehender Block 4564801273 (darf seitenübergreifend genutzt werden)
       inArticle → NEU anlegen: "In-Article-Anzeige"
       inFeed    → NEU anlegen: "In-Feed-Anzeige" (braucht zusätzlich layoutKey)
     SPONSORED_PARTNERS: nur Partner mit SCHRIFTLICHER Vereinbarung eintragen.
       Werden statt der "Hier werben"-Hausanzeige gezeigt – immer mit "Anzeige"-Kennzeichnung
       und rel="sponsored".
  ═════════════════════════════════════════════════════════ */
  const AD_CONFIG = {
    client: "ca-pub-4690558719999917",
    slots: { sidebar: "4564801273", inArticle: "", inFeed: "" },
    inFeedLayoutKey: ""
  };

  const SPONSORED_PARTNERS = [
    // Beispiel (erst nach Vertrag aktivieren):
    // { name: "Firmenname", text: "Kurzer, wahrer Werbetext.", url: "https://partner.de/",
    //   image: "", cta: "Zur Website" }
  ];

  const FAV_KEY = "1amotor-favs";
  const SITE = "https://1amotor.de";
  const state = { listing: null, images: [], idx: 0, title: "" };

  /* ═════════════════════════ START ═════════════════════════ */
  document.addEventListener("DOMContentLoaded", async () => {
    setupHeader();
    setupLightbox();
    setupContactFocus();
    initAds();

    const params = new URLSearchParams(window.location.search);
    const listingId = params.get("id") || safeLS("get", "current_listing_id");
    if (!listingId) return showNotFound("Keine Anzeige ausgewählt.");

    if (typeof supabaseClient === "undefined") return showNotFound("Verbindung zur Datenbank fehlgeschlagen. Bitte Seite neu laden.");

    const { data: listing, error } = await supabaseClient
      .from("listings")
      .select(`
        id, title, manufacturer, model, condition, price, year, location,
        description, status, created_at, image_urls, seller_id,
        categories(id, name),
        seller_profiles(id, company_name, city, country, description, paypal_email)
      `)
      .eq("id", listingId)
      .eq("status", "Freigegeben")
      .single();

    if (error || !listing) {
      if (error) console.warn("Listing-Fehler:", error);
      return showNotFound("Dieses Inserat ist nicht mehr online oder wurde noch nicht freigegeben.");
    }

    state.listing = listing;
    document.getElementById("ld-root")?.classList.remove("is-loading");

    fillListingData(listing);
    setupGallery(listing);
    setupContactForm(listing);
    setupActions(listing);
    setupTabs();
    loadShipping(listing);
    loadSimilar(listing);
    loadSellerListings(listing);
  });

  /* ═════════════════════════ DATEN FÜLLEN ═════════════════════════ */
  function fillListingData(listing) {
    const cat = categoryOf(listing);
    const seller = sellerOf(listing);
    const title = listing.title || "Motor";
    state.title = title;
    const price = fmtPrice(listing.price);
    const date = fmtDate(listing.created_at);
    const loc = (listing.location || "").trim();

    /* SEO */
    const seoTitle = `${title} – ${price} | 1A Motor`;
    const seoDesc = `${title} kaufen bei ${seller.company_name || "einem Anbieter"} auf 1A Motor. ${listing.condition || "Gebraucht"}${listing.year ? ", Baujahr " + listing.year : ""}${loc ? ", Standort: " + loc : ""}. Direkt anfragen, ohne Provision.`;
    const seoUrl = `${SITE}/listing-detail.html?id=${encodeURIComponent(listing.id)}`;
    const seoImg = firstImage(listing) || `${SITE}/hero-bg.png`;
    document.title = seoTitle;
    setAttr("meta[name='description']", "content", seoDesc);
    setAttr("link[rel='canonical']", "href", seoUrl);
    setAttr("#og-title", "content", seoTitle);
    setAttr("#og-description", "content", seoDesc);
    setAttr("#og-url", "content", seoUrl);
    setAttr("meta[property='og:image']", "content", seoImg);
    setAttr("meta[name='twitter:image']", "content", seoImg);
    setAttr("#tw-title", "content", seoTitle);
    setAttr("#tw-description", "content", seoDesc);
    const schema = document.getElementById("schema-product");
    if (schema) {
      schema.textContent = JSON.stringify({
        "@context": "https://schema.org",
        "@graph": [
          {
            "@type": "Product",
            name: title,
            description: (listing.description || seoDesc).slice(0, 500),
            image: listImages(listing).length ? listImages(listing) : [seoImg],
            ...(listing.manufacturer ? { brand: { "@type": "Brand", name: listing.manufacturer } } : {}),
            ...(listing.model ? { model: listing.model } : {}),
            category: cat.name,
            itemCondition: conditionSchema(listing.condition),
            offers: {
              "@type": "Offer", priceCurrency: "EUR", price: Number(listing.price || 0),
              availability: "https://schema.org/InStock", url: seoUrl,
              itemCondition: conditionSchema(listing.condition),
              seller: { "@type": "Organization", name: seller.company_name || "Anbieter auf 1A Motor" }
            }
          },
          {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Startseite", item: `${SITE}/` },
              { "@type": "ListItem", position: 2, name: "Suche", item: `${SITE}/suche.html` },
              { "@type": "ListItem", position: 3, name: cat.name, item: `${SITE}/${catUrl(cat.name)}` },
              { "@type": "ListItem", position: 4, name: title, item: seoUrl }
            ]
          }
        ]
      });
    }

    /* Brotkrumen */
    link("crumb-cat", catUrl(cat.name), cat.name);
    if (listing.manufacturer) link("crumb-brand", brandUrl(listing.manufacturer), listing.manufacturer);
    else { const b = byId("crumb-brand"); if (b) { b.nextElementSibling?.remove(); b.remove(); } }
    text("crumb-title", title);

    /* Kaufbox */
    link("ld-cat-chip", catUrl(cat.name), `${categoryIcon(cat.name)} ${cat.name}`);
    const condChip = byId("ld-cond-chip");
    if (condChip) { if (listing.condition) condChip.textContent = listing.condition; else condChip.remove(); }
    text("ld-title", title);
    text("ld-price", price);
    text("ld-loc-txt", loc || "Standort auf Anfrage");
    text("pl-year", listing.year || "–");
    text("pl-cond", listing.condition || "–");
    text("pl-brand", listing.manufacturer || "–");
    text("pl-model", listing.model || "–");
    text("meta-id", String(listing.id).slice(0, 8).toUpperCase());
    text("meta-date", date);
    const report = byId("ld-report");
    if (report) report.href = `kontakt.html?betreff=${encodeURIComponent("Inserat melden: " + String(listing.id).slice(0, 8).toUpperCase())}`;

    /* Anbieter */
    const sName = seller.company_name || "Anbieter auf 1A Motor";
    const sLoc = [seller.city, seller.country].filter(Boolean).join(", ") || loc || "–";
    ["strip-av", "seller-logo"].forEach(id => text(id, initials(sName)));
    text("strip-name", sName); text("seller-name", sName);
    text("strip-loc", sLoc); text("seller-location", sLoc);
    text("seller-date", date);
    const about = byId("seller-about");
    if (about && seller.description?.trim()) { about.textContent = seller.description.trim().slice(0, 280); about.hidden = false; }

    /* Beschreibung */
    const descBox = byId("description-box");
    if (descBox) {
      const d = (listing.description || "").trim();
      descBox.textContent = d || "Der Anbieter hat keine Beschreibung hinterlegt. Stell deine Fragen einfach über das Anfrageformular.";
      if (!d) descBox.style.color = "var(--muted)";
      if (d.length > 700) {
        descBox.classList.add("clamped");
        const more = byId("ld-desc-more");
        if (more) {
          more.hidden = false;
          more.onclick = () => {
            const open = descBox.classList.toggle("clamped");
            more.textContent = open ? "Ganze Beschreibung lesen" : "Weniger anzeigen";
          };
        }
      }
    }

    /* Technische Daten – mit Links in die Suche */
    const specs = byId("specs-grid");
    if (specs) {
      const rows = [
        ["Hersteller", listing.manufacturer, listing.manufacturer && brandUrl(listing.manufacturer)],
        ["Modell", listing.model],
        ["Kategorie", cat.name, catUrl(cat.name)],
        ["Zustand", listing.condition, listing.condition && `suche.html?category=${encodeURIComponent(cat.name)}&condition=${encodeURIComponent(listing.condition)}`],
        ["Baujahr", listing.year],
        ["Standort", loc],
        ["Preis", price],
        ["Inserat-Nr.", String(listing.id).slice(0, 8).toUpperCase()]
      ];
      specs.innerHTML = rows.map(([k, v, href]) => {
        const val = v ? esc(String(v)) : "–";
        return `<div><span>${esc(k)}</span><strong>${href && v ? `<a href="${esc(href)}">${val}</a>` : val}</strong></div>`;
      }).join("");
    }

    /* Standort / Werkstätten */
    if (loc) {
      text("loc-sub", `Der Motor steht in ${loc}. Für Ein- und Ausbau findest du Fachbetriebe in der Umgebung.`);
      setAttr("#map-route", "href", `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(loc)}`);
      setAttr("#map-shops", "href", `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("Motorinstandsetzung Werkstatt " + loc)}`);
      setAttr("#ld-loc", "href", "#standort");
    } else {
      text("loc-sub", "Der Anbieter hat keinen Standort angegeben. Frag ihn einfach über das Anfrageformular.");
      setAttr("#map-shops", "href", "https://www.google.com/maps/search/?api=1&query=Motorinstandsetzung%20Werkstatt");
      const r = byId("map-route"); if (r) r.remove();
    }

    /* Mobile Leiste */
    text("mbar-price", price);
    text("mbar-title", title);
    setupMobileBar();

    /* PayPal */
    const pp = (seller.paypal_email || "").trim();
    const ppWrap = byId("paypal-cta-wrap"), ppBtn = byId("paypal-btn");
    if (pp && ppWrap && ppBtn) {
      const amount = Number(listing.price || 0).toFixed(2);
      ppBtn.href = pp.includes("paypal.me")
        ? (pp.startsWith("http") ? pp : "https://" + pp).replace(/\/+$/, "") + "/" + amount + "EUR"
        : "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=" + encodeURIComponent(pp) +
          "&item_name=" + encodeURIComponent(title.slice(0, 80)) + "&amount=" + amount + "&currency_code=EUR&no_shipping=1";
      ppWrap.style.display = "block";
    }

    /* Für reviews.js */
    if (seller.id) window._currentSellerId = seller.id;
  }
  window._setSellerIdFromListing = function (listing) {
    const s = sellerOf(listing); if (s.id) window._currentSellerId = s.id;
  };

  /* ═════════════════════════ GALERIE ═════════════════════════ */
  function setupGallery(listing) {
    state.images = listImages(listing);
    const img = byId("ld-stage-img"), noimg = byId("ld-noimg"), thumbs = byId("ld-thumbs");
    const stage = byId("ld-stage");

    if (!state.images.length) {
      if (noimg) noimg.textContent = categoryIcon(categoryOf(listing).name);
      const t = byId("ld-noimg-txt"); if (t) t.hidden = false;
      if (stage) stage.style.cursor = "default";
      return;
    }
    if (noimg) noimg.hidden = true;
    if (img) { img.hidden = false; img.alt = state.title; }
    const multi = state.images.length > 1;
    ["ld-prev", "ld-next", "ld-counter"].forEach(id => { const e = byId(id); if (e) e.hidden = !multi; });
    const z = byId("ld-zoom"); if (z) z.hidden = false;

    if (thumbs && multi) {
      thumbs.innerHTML = state.images.map((u, i) =>
        `<button type="button" class="ld-thumb${i === 0 ? " active" : ""}" data-idx="${i}" aria-label="Bild ${i + 1}" style="background-image:url('${cssUrl(u)}')"></button>`
      ).join("");
      thumbs.addEventListener("click", e => {
        const b = e.target.closest(".ld-thumb"); if (b) show(parseInt(b.dataset.idx, 10));
      });
    }
    byId("ld-prev")?.addEventListener("click", e => { e.stopPropagation(); show(state.idx - 1); });
    byId("ld-next")?.addEventListener("click", e => { e.stopPropagation(); show(state.idx + 1); });
    byId("ld-zoom")?.addEventListener("click", e => { e.stopPropagation(); openLightbox(); });
    stage?.addEventListener("click", () => openLightbox());
    stage?.addEventListener("keydown", e => {
      if (e.key === "ArrowLeft") show(state.idx - 1);
      if (e.key === "ArrowRight") show(state.idx + 1);
      if (e.key === "Enter") openLightbox();
    });
    addSwipe(stage, dir => show(state.idx + dir));
    show(0);

    // Folgebilder vorladen
    state.images.slice(1, 4).forEach(u => { const p = new Image(); p.src = u; });
  }

  function show(i) {
    const n = state.images.length; if (!n) return;
    state.idx = (i + n) % n;
    const url = state.images[state.idx];
    const img = byId("ld-stage-img"); if (img) img.src = url;
    text("ld-counter", `${state.idx + 1} / ${n}`);
    document.querySelectorAll(".ld-thumb").forEach((t, k) => t.classList.toggle("active", k === state.idx));
    document.querySelector(".ld-thumb.active")?.scrollIntoView({ block: "nearest", inline: "nearest" });
    if (byId("ld-lb")?.classList.contains("open")) {
      const lb = byId("ld-lb-img"); if (lb) lb.src = url;
      text("ld-lb-count", `${state.idx + 1} / ${n}`);
    }
  }

  /* ═════════════════════════ LIGHTBOX ═════════════════════════ */
  function setupLightbox() {
    const lb = byId("ld-lb"); if (!lb) return;
    byId("ld-lb-close")?.addEventListener("click", closeLightbox);
    byId("ld-lb-prev")?.addEventListener("click", () => show(state.idx - 1));
    byId("ld-lb-next")?.addEventListener("click", () => show(state.idx + 1));
    lb.addEventListener("click", e => { if (e.target === lb) closeLightbox(); });
    document.addEventListener("keydown", e => {
      if (!lb.classList.contains("open")) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowLeft") show(state.idx - 1);
      if (e.key === "ArrowRight") show(state.idx + 1);
    });
    addSwipe(lb, dir => show(state.idx + dir));
  }
  function openLightbox() {
    if (!state.images.length) return;
    const lb = byId("ld-lb"); if (!lb) return;
    const multi = state.images.length > 1;
    ["ld-lb-prev", "ld-lb-next"].forEach(id => { const e = byId(id); if (e) e.hidden = !multi; });
    lb.classList.add("open");
    document.body.style.overflow = "hidden";
    show(state.idx);
    byId("ld-lb-close")?.focus();
  }
  function closeLightbox() {
    byId("ld-lb")?.classList.remove("open");
    document.body.style.overflow = "";
    byId("ld-stage")?.focus();
  }
  function addSwipe(el, cb) {
    if (!el) return;
    let x0 = null;
    el.addEventListener("touchstart", e => { x0 = e.touches[0].clientX; }, { passive: true });
    el.addEventListener("touchend", e => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) > 40) cb(dx < 0 ? 1 : -1);
    }, { passive: true });
  }

  /* ═════════════════════════ AKTIONEN ═════════════════════════ */
  function setupActions(listing) {
    const id = String(listing.id);
    const fav = byId("ld-fav");
    const paint = () => {
      const on = loadFavs().includes(id);
      fav?.classList.toggle("on", on);
      fav?.setAttribute("aria-pressed", String(on));
      const s = fav?.querySelector("span"); if (s) s.textContent = on ? "Gemerkt" : "Merken";
    };
    paint();
    fav?.addEventListener("click", () => {
      const f = loadFavs(); const i = f.indexOf(id);
      if (i > -1) { f.splice(i, 1); toast("Von der Merkliste entfernt"); } else { f.push(id); toast("Zur Merkliste hinzugefügt"); }
      safeLS("set", FAV_KEY, JSON.stringify(f)); paint();
    });

    byId("ld-share")?.addEventListener("click", async () => {
      const url = `${SITE}/listing-detail.html?id=${encodeURIComponent(id)}`;
      const data = { title: state.title, text: `${state.title} – ${fmtPrice(listing.price)} auf 1A Motor`, url };
      try {
        if (navigator.share) { await navigator.share(data); return; }
        await navigator.clipboard.writeText(url); toast("Link kopiert");
      } catch (e) {
        if (e && e.name === "AbortError") return;
        window.prompt("Link zum Kopieren:", url);
      }
    });
  }

  function setupContactFocus() {
    document.querySelectorAll("[data-focus-contact]").forEach(a => a.addEventListener("click", e => {
      e.preventDefault();
      byId("kontakt")?.scrollIntoView({ behavior: "smooth", block: "start" });
      setTimeout(() => { const f = byId("cf-name"); (f && !f.value ? f : byId("cf-message"))?.focus({ preventScroll: true }); }, 450);
    }));
  }

  function setupTabs() {
    const tabs = Array.from(document.querySelectorAll(".ld-tabs a"));
    if (!("IntersectionObserver" in window) || !tabs.length) return;
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (!en.isIntersecting) return;
        tabs.forEach(t => t.classList.toggle("active", t.getAttribute("href") === "#" + en.target.id));
      });
    }, { rootMargin: "-40% 0px -55% 0px" });
    tabs.forEach(t => { const s = document.querySelector(t.getAttribute("href")); if (s) io.observe(s); });
  }

  function setupMobileBar() {
    const bar = byId("ld-mbar"), cta = byId("ld-cta"), contact = byId("kontakt");
    if (!bar || !cta || !("IntersectionObserver" in window)) return;
    let ctaVisible = true, contactVisible = false;
    const upd = () => bar.classList.toggle("show", !ctaVisible && !contactVisible);
    new IntersectionObserver(([e]) => { ctaVisible = e.isIntersecting; upd(); }).observe(cta);
    if (contact) new IntersectionObserver(([e]) => { contactVisible = e.isIntersecting; upd(); }).observe(contact);
  }

  function setupHeader() {
    // Fallback, falls die Seite ohne Registrierungs-Dialog der Startseite geladen wird
    if (typeof window.openAccountChooser !== "function") {
      window.openAccountChooser = function (e) { if (e) e.preventDefault(); location.href = "registrieren.html"; };
    }
    // Hamburger zwischen 769–900 px (darunter übernimmt mobile.js)
    const t = byId("mob-toggle"), nav = byId("mob-nav");
    t?.addEventListener("click", () => {
      if (window.innerWidth <= 768) return;
      const open = nav.classList.toggle("open"); t.setAttribute("aria-expanded", String(open));
    });
  }

  /* ═════════════════════════ VERSAND ═════════════════════════ */
  async function loadShipping(listing) {
    try {
      const { data, error } = await supabaseClient.from("listings").select("shipping_options").eq("id", listing.id).single();
      if (error || !data) return;
      renderShipping(data.shipping_options);
    } catch (e) { /* Spalte existiert ggf. nicht – Versand-Bereich bleibt ausgeblendet */ }
  }

  function renderShipping(options) {
    const panel = byId("shipping-panel"), list = byId("shipping-options-list"), wantShip = byId("cf-want-shipping");
    if (typeof options === "string") { try { options = JSON.parse(options); } catch (e) { options = null; } }
    if (!panel || !list || !Array.isArray(options) || !options.length) return;

    const carriers = {
      DHL: ["🟡", "Paket, 1–2 Werktage"], DPD: ["🔴", "Paket, 1–2 Werktage"], Hermes: ["🟢", "Paket, 2–4 Werktage"],
      UPS: ["🟤", "Paket, 1–3 Werktage"], Spedition: ["🚛", "Spedition, auf Anfrage"], Abholung: ["🏠", "Selbst abholen"]
    };
    list.innerHTML = options.map(o => {
      const [emoji, note] = carriers[o.carrier] || ["📦", "Versand"];
      const p = o.price == null || o.price === "" ? '<span class="ship-price">auf Anfrage</span>'
        : Number(o.price) === 0 ? '<span class="ship-price free">Kostenlos</span>'
        : `<span class="ship-price">+ ${Number(o.price).toLocaleString("de-DE", { minimumFractionDigits: 2 })} €</span>`;
      return `<div class="ship-opt"><div class="ship-opt-left"><div class="ship-logo">${emoji}</div><div>
        <div class="ship-name">${esc(o.carrier || "Versand")}</div><div class="ship-note">${note}</div></div></div>${p}</div>`;
    }).join("");
    panel.style.display = "block";
    const sec = byId("versand"); if (sec) sec.style.display = "";
    const tab = byId("tab-ship"); if (tab) tab.hidden = false;
    if (wantShip && options.some(o => o.carrier !== "Abholung")) wantShip.style.display = "block";
  }
  window.toggleAddressForm = function (showIt) { byId("cf-address-wrap")?.classList.toggle("show", !!showIt); };

  /* ═════════════════════════ ÄHNLICHE ANZEIGEN ═════════════════════════ */
  async function loadSimilar(listing) {
    const cat = categoryOf(listing);
    const cols = "id, title, price, condition, year, location, image_urls, categories(name)";
    const want = 4, seen = new Set([String(listing.id)]), out = [];
    const add = rows => (rows || []).forEach(r => { if (out.length < want && !seen.has(String(r.id))) { seen.add(String(r.id)); out.push(r); } });
    const base = () => supabaseClient.from("listings").select(cols).eq("status", "Freigegeben").neq("id", listing.id);

    try {
      if (cat.id) add((await base().eq("category_id", cat.id).order("created_at", { ascending: false }).limit(8)).data);
      if (out.length < want && listing.manufacturer) add((await base().ilike("manufacturer", listing.manufacturer).limit(8)).data);
      if (out.length < want) add((await base().order("created_at", { ascending: false }).limit(8)).data);
    } catch (e) { console.warn("Ähnliche Anzeigen:", e); }

    const panel = byId("similar-panel"), grid = byId("similar-grid");
    if (!panel || !grid || !out.length) return;
    setAttr("#similar-all", "href", catUrl(cat.name));

    const realAd = !!(AD_CONFIG.slots.inFeed && AD_CONFIG.inFeedLayoutKey) || SPONSORED_PARTNERS.length > 0;
    const shown = out.slice(0, realAd ? 3 : 4);
    const cards = shown.map(s => {
      const img = firstImage(s);
      const meta = [s.condition, s.year, s.location].filter(Boolean).map(v => esc(String(v))).join(", ");
      return `<a class="ld-sim" href="listing-detail.html?id=${encodeURIComponent(s.id)}">
        <div class="im" style="${img ? `background-image:url('${cssUrl(img)}')` : ""}">${img ? "" : categoryIcon(categoryOf(s).name)}</div>
        <div class="bd"><div class="t">${esc(s.title || "Motor")}</div><div class="p">${fmtPrice(s.price)}</div><div class="m">${meta}</div></div></a>`;
    });
    // Letzte Kachel = gekennzeichnete Werbefläche, optisch klar von Inseraten abgesetzt.
    // Nur wenn echte Werbung (AdSense In-Feed oder Vertragspartner) konfiguriert ist –
    // sonst gibt es hier keine Eigenwerbung, damit die Seite nicht mit "Hier werben" überladen wird.
    if (realAd) cards.push(`<div class="ld-sim-ad ld-ad" data-ad-placement="inFeed">
      <div class="ld-ad-label"><span>Anzeige</span></div><div class="ld-ad-body"></div></div>`);
    grid.innerHTML = cards.join("");
    panel.hidden = false;
    initAds();
  }

  /* ═════════════════════════ WEITERE INSERATE DES ANBIETERS ═════════════════════════ */
  async function loadSellerListings(listing) {
    if (!listing.seller_id) { text("seller-count", "–"); return; }
    try {
      const { data, count } = await supabaseClient.from("listings")
        .select("id, title, price, image_urls, categories(name)", { count: "exact" })
        .eq("status", "Freigegeben").eq("seller_id", listing.seller_id)
        .order("created_at", { ascending: false }).limit(4);
      text("seller-count", count != null ? String(count) : "–");
      const others = (data || []).filter(r => String(r.id) !== String(listing.id)).slice(0, 3);
      if (!others.length) return;
      const box = byId("seller-more");
      if (box) box.innerHTML = others.map(s => {
        const img = firstImage(s);
        return `<a class="ld-more-item" href="listing-detail.html?id=${encodeURIComponent(s.id)}">
          <div class="im" style="${img ? `background-image:url('${cssUrl(img)}')` : ""}">${img ? "" : categoryIcon(categoryOf(s).name)}</div>
          <div><div class="t">${esc(s.title || "Motor")}</div><div class="p">${fmtPrice(s.price)}</div></div></a>`;
      }).join("");
      const w = byId("seller-more-wrap"); if (w) w.hidden = false;
    } catch (e) { console.warn("Anbieter-Inserate:", e); }
  }

  /* ═════════════════════════ KONTAKTFORMULAR ═════════════════════════ */
  async function setupContactForm(listing) {
    const form = byId("contact-form"); if (!form) return;
    const msg = byId("cf-message");
    if (msg && !msg.value) msg.value = `Hallo,\n\nich interessiere mich für „${state.title}“ (Inserat-Nr. ${String(listing.id).slice(0, 8).toUpperCase()}).\n\n`;

    // Eingeloggte Nutzer: E-Mail vorausfüllen
    try {
      const { data } = await supabaseClient.auth.getSession();
      const u = data?.session?.user;
      if (u) {
        const em = byId("cf-email"); if (em && !em.value) em.value = u.email || "";
        const nm = byId("cf-name"); const full = u.user_metadata?.full_name || u.user_metadata?.name;
        if (nm && !nm.value && full) nm.value = full;
      }
    } catch (e) { /* Gast */ }

    document.querySelectorAll(".ld-quick button").forEach(b => b.addEventListener("click", () => {
      if (!msg) return;
      const q = b.dataset.q;
      if (!msg.value.includes(q)) msg.value = msg.value.replace(/\s*$/, "") + (msg.value.trim() ? "\n" : "") + q + "\n";
      msg.focus(); msg.setSelectionRange(msg.value.length, msg.value.length);
    }));

    form.addEventListener("submit", async e => {
      e.preventDefault();
      const btn = byId("cf-submit");
      const name = (byId("cf-name")?.value || "").trim();
      const email = (byId("cf-email")?.value || "").trim();
      const message = (msg?.value || "").trim();

      if (!name || !email || !message) return formError("Bitte Name, E-Mail und Nachricht ausfüllen.");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return formError("Bitte eine gültige E-Mail-Adresse eingeben.");

      let address = "";
      if (byId("cf-needs-shipping")?.checked) {
        const v = id => (byId(id)?.value || "").trim();
        if (!v("addr-street") || !v("addr-zip") || !v("addr-city")) return formError("Bitte Straße, PLZ und Ort für die Lieferung angeben.");
        address = `\n\n📦 LIEFERADRESSE:\n${v("addr-firstname")} ${v("addr-lastname")}\n${v("addr-street")}\n${v("addr-zip")} ${v("addr-city")}`;
      }

      if (btn) { btn.disabled = true; btn.textContent = "Wird gesendet …"; }
      let buyer = null;
      try { buyer = (await supabaseClient.auth.getSession()).data?.session?.user?.id || null; } catch (e) {}

      const { error } = await supabaseClient.from("inquiries").insert([{
        listing_id: listing.id, name, email, message: message + address, status: "Neu", buyer_user_id: buyer
      }]);

      if (error) {
        console.warn("Anfrage-Fehler:", error);
        if (btn) { btn.disabled = false; btn.textContent = "Nachricht senden"; }
        return formError("Senden hat nicht geklappt. Bitte prüfe deine Verbindung und versuche es erneut.");
      }
      const ok = byId("send-success"); if (ok) ok.style.display = "block";
      form.reset();
      window.toggleAddressForm(false);
      if (btn) { btn.textContent = "✓ Gesendet"; btn.style.background = "linear-gradient(135deg,#059669,#0ea371)"; }
    });
  }
  function formError(m) {
    byId("cf-error-msg")?.remove();
    const el = document.createElement("div");
    el.id = "cf-error-msg"; el.setAttribute("role", "alert");
    el.style.cssText = "background:#fff5f5;border:1px solid #fca5a5;color:#b91c1c;padding:10px 14px;border-radius:10px;font-size:13.5px;margin-top:10px;";
    el.textContent = m;
    byId("cf-submit")?.insertAdjacentElement("afterend", el);
    setTimeout(() => el.remove(), 6000);
  }

  /* ═════════════════════════ WERBUNG ═════════════════════════
     Regeln (AdSense-Programmrichtlinien + §5a Abs. 4 UWG):
     - jede Fläche trägt sichtbar "Anzeige"
     - Werbung ist optisch von Inseraten abgesetzt (eigene Farbe, gestrichelter Rahmen)
     - keine Werbung direkt neben Kontakt-/Kaufbuttons (Fehlklick-Gefahr)
     - AdSense lädt erst nach Einwilligung "Werbung" (cookie-consent.js)
  ═══════════════════════════════════════════════════════════ */
  function initAds() {
    document.querySelectorAll("[data-ad-placement]").forEach(box => {
      const body = box.querySelector(".ld-ad-body");
      if (!body) return;
      if (!body.dataset.house) { body.insertAdjacentHTML("beforeend", houseAd(box.dataset.adPlacement)); body.dataset.house = "1"; }
      mountAdSense(box);
    });
  }
  function mountAdSense(box) {
    const key = box.dataset.adPlacement, slot = AD_CONFIG.slots[key];
    const body = box.querySelector(".ld-ad-body");
    if (!slot || !body || body.dataset.ins || !marketingConsent()) return;
    if (key === "inFeed" && !AD_CONFIG.inFeedLayoutKey) return;
    const ins = document.createElement("ins");
    ins.className = "adsbygoogle";
    ins.setAttribute("data-ad-client", AD_CONFIG.client);
    ins.setAttribute("data-ad-slot", slot);
    if (key === "inArticle") { ins.setAttribute("data-ad-layout", "in-article"); ins.setAttribute("data-ad-format", "fluid"); ins.style.textAlign = "center"; }
    else if (key === "inFeed") { ins.setAttribute("data-ad-format", "fluid"); ins.setAttribute("data-ad-layout-key", AD_CONFIG.inFeedLayoutKey); }
    else { ins.setAttribute("data-ad-format", "auto"); ins.setAttribute("data-full-width-responsive", "true"); }
    body.insertBefore(ins, body.firstChild);
    body.dataset.ins = "1";
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { console.warn("AdSense:", e); }
  }
  function marketingConsent() { return !!(window.__1amConsent && window.__1amConsent.marketing); }
  document.addEventListener("1am-consent-changed", () => document.querySelectorAll("[data-ad-placement]").forEach(mountAdSense));

  function houseAd(key) {
    if (SPONSORED_PARTNERS.length) {
      const seed = String(state.listing?.id || location.pathname).split("").reduce((a, c) => a + c.charCodeAt(0), 0);
      const order = { sidebar: 0, inArticle: 1, inFeed: 2 }[key] || 0;
      const p = SPONSORED_PARTNERS[(seed + order) % SPONSORED_PARTNERS.length];
      const url = p.url + (p.url.includes("?") ? "&" : "?") + "utm_source=1amotor&utm_medium=" + encodeURIComponent(key);
      return `<a class="ld-house" href="${esc(url)}" target="_blank" rel="sponsored noopener">
        ${p.image ? `<img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy" />` : ""}
        <b>${esc(p.name)}</b><p>${esc(p.text)}</p><span class="go">${esc(p.cta || "Zur Website")}</span></a>`;
    }
    const texts = {
      sidebar: ["Ihre Werkstatt hier", "Erreichen Sie Käufer genau dann, wenn sie einen Motor suchen – direkt neben passenden Inseraten."],
      inArticle: ["Motorinstandsetzung, Teilehandel oder Spedition?", "Platzieren Sie Ihr Angebot auf den Inseratsseiten von 1A Motor."],
      inFeed: ["Werbeplatz frei", "Ihre Anzeige zwischen passenden Motor-Angeboten."]
    };
    const [h, t] = texts[key] || texts.sidebar;
    return `<a class="ld-house" href="kontakt.html?betreff=${encodeURIComponent("Werbung auf 1A Motor")}">
      <b>${esc(h)}</b><p>${esc(t)}</p><span class="go">Werbeplatz anfragen</span></a>`;
  }

  /* ═════════════════════════ NICHT GEFUNDEN ═════════════════════════ */
  function showNotFound(message) {
    const main = document.querySelector("main"); if (!main) return;
    main.classList.remove("is-loading");
    main.innerHTML = `
      <div class="container" style="padding:64px 20px;">
        <div style="max-width:500px;margin:0 auto;background:#fff;border:1px solid #e0e9f2;border-radius:16px;padding:40px;text-align:center;">
          <div style="font-size:48px;margin-bottom:14px;">🔍</div>
          <h1 style="font-size:22px;font-weight:800;margin-bottom:10px;">Inserat nicht verfügbar</h1>
          <p style="color:#6b8199;margin-bottom:24px;">${esc(message)}</p>
          <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
            <a href="suche.html" class="ld-btn ld-btn-primary">Ähnliche Motoren suchen</a>
            <a href="index.html" class="ld-btn ld-btn-ghost">Zur Startseite</a>
          </div>
        </div>
      </div>`;
    const bar = byId("ld-mbar"); if (bar) bar.remove();
    const robots = document.querySelector("meta[name='robots']"); if (robots) robots.content = "noindex, follow";
  }

  /* ═════════════════════════ HELFER ═════════════════════════ */
  function byId(id) { return document.getElementById(id); }
  function text(id, v) { const e = byId(id); if (e) e.textContent = v; }
  function link(id, href, label) { const e = byId(id); if (e) { e.href = href; if (label != null) e.textContent = label; } }
  function setAttr(sel, attr, val) {
    let el = document.querySelector(sel);
    if (!el && sel.startsWith("link")) { el = document.createElement("link"); el.rel = "canonical"; document.head.appendChild(el); }
    if (!el && sel.startsWith("meta")) { el = document.createElement("meta"); document.head.appendChild(el); }
    if (el) el.setAttribute(attr, val);
  }
  function esc(v) {
    return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  function cssUrl(u) { return String(u).replace(/['"()\\\s]/g, c => encodeURIComponent(c)); }
  function initials(t) { return String(t).split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase() || "?"; }
  function fmtPrice(p) {
    const n = Number(p || 0);
    if (!n) return "Preis auf Anfrage";
    return n.toLocaleString("de-DE", { style: "currency", currency: "EUR", maximumFractionDigits: n % 1 ? 2 : 0 });
  }
  function fmtDate(d) { const x = new Date(d); return isNaN(x) ? "–" : x.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }); }
  function categoryOf(l) {
    const c = Array.isArray(l.categories) ? l.categories[0] : l.categories;
    return { id: c?.id || null, name: c?.name || "Sonstiges" };
  }
  function sellerOf(l) { return (Array.isArray(l.seller_profiles) ? l.seller_profiles[0] : l.seller_profiles) || {}; }
  function listImages(l) { return Array.isArray(l.image_urls) ? l.image_urls.filter(Boolean) : []; }
  function firstImage(l) { return listImages(l)[0] || ""; }
  function catUrl(name) { return `suche.html?category=${encodeURIComponent(name)}`; }
  function brandUrl(name) { return `suche.html?q=${encodeURIComponent(name)}`; }
  function conditionSchema(c) {
    const s = String(c || "").toLowerCase();
    if (s.startsWith("neu")) return "https://schema.org/NewCondition";
    if (s.includes("überholt") || s.includes("ueberholt") || s.includes("austausch")) return "https://schema.org/RefurbishedCondition";
    return "https://schema.org/UsedCondition";
  }
  function loadFavs() { try { return JSON.parse(safeLS("get", FAV_KEY) || "[]"); } catch (e) { return []; } }
  function safeLS(op, k, v) { try { return op === "get" ? localStorage.getItem(k) : localStorage.setItem(k, v); } catch (e) { return null; } }
  let toastT;
  function toast(m) {
    const t = byId("ld-toast"); if (!t) return;
    t.textContent = m; t.classList.add("show");
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 2200);
  }
  function categoryIcon(c) {
    const map = {
      "Automotor": "🚗", "Dieselmotor Auto": "🚗", "Benzinmotor Auto": "🚗", "Hybridmotor": "⚡", "Elektromotor Auto": "⚡",
      "Motorradmotor": "🏍️", "Roller Motor": "🛵", "LKW Motor": "🚛", "Busmotor": "🚌", "Traktormotor": "🚜",
      "Landmaschinenmotor": "🚜", "Baumaschinenmotor": "🚧", "Baggermotor": "🚧", "Gabelstapler Motor": "🏗️",
      "Bootsmotor": "🚤", "Außenbordmotor": "🚤", "Innenbordmotor": "🚤", "Schiffsdieselmotor": "🛳️", "Jetski Motor": "🌊",
      "Flugzeugmotor": "✈️", "Turbinenmotor": "✈️", "Elektromotor Industrie": "⚙️", "Drehstrommotor": "⚙️",
      "Servomotor": "🤖", "Getriebemotor": "🔩", "Generator Motor": "🔋", "Pumpenmotor": "💧", "Kompressormotor": "🌀",
      "Lüftermotor": "🌬️", "Kranmotor": "🏗️", "Aufzugmotor": "🏢", "Achterbahnmotor": "🎢", "Arcade Motor": "🕹️",
      "Drohnenmotor": "🚁", "E-Bike Motor": "🚲", "Rasenmähermotor": "🌱", "Aufsitzmäher Motor": "🌱",
      "Hochleistungsmotor": "🔥", "CNC Motor": "🧰", "Robotermotor": "🤖", "Austauschmotor": "🔄", "Sonstiges": "📦"
    };
    return map[c] || "⚙️";
  }
})();
